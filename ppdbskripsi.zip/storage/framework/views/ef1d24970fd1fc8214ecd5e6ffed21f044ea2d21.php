<?php echo $__env->make('user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
                <!-- End of Topbar -->                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Halaman Utama</h1>
                    <p><b>Hai... <?php echo e(auth()->user()->name); ?></b> Silahkan Lengkapi pendaftaranmu.</p>
                    <?php if(session()->has('sukses')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                      <?php echo e(session('sukses')); ?>

                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(session()->has('loginError')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <?php echo e(session('loginError')); ?>

                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>

                </div>
                <!-- /.container-fluid -->
<?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp2\htdocs\ppdbskripsi\resources\views/user/dashboard.blade.php ENDPATH**/ ?>