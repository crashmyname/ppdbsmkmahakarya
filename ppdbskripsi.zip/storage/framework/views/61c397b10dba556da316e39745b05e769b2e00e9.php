<?php echo $__env->make('user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End of Topbar --><div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <!-- DATA AYAH -->
            <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title">Kirim Pertanyaan</h3>
            </div>
            <div class="card-body">
                <?php if(session()->has('sukses')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('sukses')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <form action="/pesan" method="post">
                    <?php echo csrf_field(); ?>
                <div class="form-group row">
                <label for="nik_ayh" class="col-sm-4 col-form-label">Nama Siswa</label>
                <div class="col-sm-8">
                    <input type="text" name="nama_siswa" class="form-control" value="<?php echo e(auth()->user()->name); ?>" readonly>
                </div>
                </div>
                <div class="form-group row">
                <label for="pesan" class="col-sm-4 col-form-label">Masukan pesan pertanyaan?</label>
                <div class="col-sm-8">
                    <textarea class="form-control" name="pesan" id="" cols="30" rows="10"></textarea>
                </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-info">Kirim</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        </div>
</div>

    <!-- End of Main Content -->
    <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\ppdbskripsi\resources\views/user/faq.blade.php ENDPATH**/ ?>