<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<div class="container-fluid">
           
    <!-- Horizontal Form -->
    <!-- DATA SISWA -->
    <div class="card card-info col-8">
        <div class="card-header">
            <h3 class="card-title">Edit Jurusan</h3>
        </div>
        
        <?php $__currentLoopData = $datajurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="/ejurusan/<?php echo e($item->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card-body">
                            <div class="form-group row">
                                <label for="Nisn" class="col-sm-4 col-form-label">Nama Jurusan</label>
                                <div class="col-sm-8">
                                    <input type="text" name="nama_jurusan" class="form-control" placeholder="Nama Jurusan" required value="<?php echo e($item->nama_jurusan); ?>">
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-success">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </form>
</div>


<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\ppdbskripsi\resources\views/admin/formeditjurusan.blade.php ENDPATH**/ ?>