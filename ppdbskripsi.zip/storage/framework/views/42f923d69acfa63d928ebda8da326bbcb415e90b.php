<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- HOME -->
<br><br><br><br>
<section class="jumbotron text-center">
      <div class="container">
        <div class="row">
          <div class="col"><h1 class="display-4"><br> Selamat Datang</h1>
            <p class="lead">Di Web PPDB Online SMK Mahakarya Cikupa 
              <div class="list-group">
                 <a href="/register" class="list-group-item list-group-item-action active" aria-current="true">
                    Mulai Daftar Disini
                  </a></p></div>
              </div><br>
          <div class="col"><img src="./img/bg1.png" alt="smk" width="400" class="responsive"></div>
        </div>
      </div>
        
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#0099ff" fill-opacity="1" d="M0,32L34.3,26.7C68.6,21,137,11,206,53.3C274.3,96,343,192,411,202.7C480,213,549,139,617,117.3C685.7,96,754,128,823,170.7C891.4,213,960,267,1029,272C1097.1,277,1166,235,1234,197.3C1302.9,160,1371,128,1406,112L1440,96L1440,320L1405.7,320C1371.4,320,1303,320,1234,320C1165.7,320,1097,320,1029,320C960,320,891,320,823,320C754.3,320,686,320,617,320C548.6,320,480,320,411,320C342.9,320,274,320,206,320C137.1,320,69,320,34,320L0,320Z"></path></svg>
</section>
<?php /**PATH C:\xampp2\htdocs\ppdbskripsi\resources\views/welcome.blade.php ENDPATH**/ ?>