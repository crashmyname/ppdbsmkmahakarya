<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Detail Siswa</h1>
        <p class="mb-4">Berikut adalah halaman Detail Siswa SMK Mahakarya Cikupa.</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <?php if(session()->has('sukses')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo e(session('sukses')); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <?php if(session()->has('delete')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo e(session('sukses')); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table Siswa</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="">
                    <table class="table table-bordered" id="table-datatables" width="100%" cellspacing="0">
                        <thead>
                            <tr align="center">
                                
                                <th>Nisn</th>
                                <th>Nama Siswa</th>
                                <th>Jenis Kelamin</th>
                                <th>Tempat Lahir</th>
                                <th>Tanggal Lahir</th>
                                <th>Agama</th>
                                <th>Alamat</th>
                                <th>RT</th>
                                <th>RW</th>
                                <th>Kelurahan</th>
                                <th>Kecamatan</th>
                                <th>Kabupaten</th>
                                <th>Provinsi</th>
                                <th>No HP</th>
                                <th>Email</th>
                                <th>Nama Ayah</th>
                                <th>Tempat Lahir Ayah</th>
                                <th>Tanggal Lahir Ayah</th>
                                <th>Pendidikan Ayah</th>
                                <th>Pekerjaan Ayah</th>
                                <th>Penghasilan Ayah</th>
                                <th>Nama Ibu</th>
                                <th>Tempat Lahir Ibu</th>
                                <th>Tanggal Lahir Ibu</th>
                                <th>Pendidikan Ibu</th>
                                <th>Pekerjaan Ibu</th>
                                <th>Penghasilan Ibu</th>
                                <th>Nama Wali</th>
                                <th>Tempat Lahir Wali</th>
                                <th>Tanggal Lahir Wali</th>
                                <th>Pendidikan Wali</th>
                                <th>Pekerjaan Wali</th>
                                <th>Penghasilan Wali</th>
                                <th>Asal Sekolah</th>
                                <th>Jurusan</th>
                            </tr>
                        </thead>
                            <?php $__currentLoopData = $datajurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr align="center">
                                <th><?php echo e($item->nisn); ?></th>
                                <th><?php echo e($item->nama_lengkap); ?></th>
                                <th><?php echo e($item->jenis_kelamin); ?></th>
                                <th><?php echo e($item->tempat_lahir); ?></th>
                                <th><?php echo e($item->tanggal_lahir); ?></th>
                                <th><?php echo e($item->agama); ?></th>
                                <th><?php echo e($item->alamat); ?></th>
                                <th><?php echo e($item->rt); ?></th>
                                <th><?php echo e($item->rw); ?></th>
                                <th><?php echo e($item->kelurahan); ?></th>
                                <th><?php echo e($item->kecamatan); ?></th>
                                <th><?php echo e($item->kabupaten); ?></th>
                                <th><?php echo e($item->provinsi); ?></th>
                                <th><?php echo e($item->no_telp); ?></th>
                                <th><?php echo e($item->email); ?></th>
                                <th><?php echo e($item->nama_ayah); ?></th>
                                <th><?php echo e($item->tempat_lahir_ayah); ?></th>
                                <th><?php echo e($item->tgl_lahir_ayah); ?></th>
                                <th><?php echo e($item->pendidikan_ayah); ?></th>
                                <th><?php echo e($item->pekerjaan_ayah); ?></th>
                                <th><?php echo e($item->penghasilan_ayah); ?></th>
                                <th><?php echo e($item->nama_ibu); ?></th>
                                <th><?php echo e($item->tempat_lahir_ibu); ?></th>
                                <th><?php echo e($item->tgl_lahir_ibu); ?></th>
                                <th><?php echo e($item->pendidikan_ibu); ?></th>
                                <th><?php echo e($item->pekerjaan_ibu); ?></th>
                                <th><?php echo e($item->penghasilan_ibu); ?></th>
                                <th><?php echo e($item->nama_wali); ?></th>
                                <th><?php echo e($item->tempat_lahir_wali); ?></th>
                                <th><?php echo e($item->tgl_lahir_wali); ?></th>
                                <th><?php echo e($item->pendidikan_wali); ?></th>
                                <th><?php echo e($item->pekerjaan_wali); ?></th>
                                <th><?php echo e($item->penghasilan_wali); ?></th>
                                <th><?php echo e($item->nama_sekolah); ?></th>
                                <th><?php echo e($item->jurusan); ?></th>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\ppdbskripsi\resources\views/admin/djlaporan.blade.php ENDPATH**/ ?>