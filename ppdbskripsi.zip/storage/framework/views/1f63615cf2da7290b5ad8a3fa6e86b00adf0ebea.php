<?php echo $__env->make('user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End of Topbar --><div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <!-- DATA AYAH -->
            <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title">Informasi Pembayaran</h3>
            </div>                
            
            <div class="card-body">
                 <?php if(session()->has('sukses')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('sukses')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <?php $__errorArgs = ['nama_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  Anda Sudah melakukan Pembayaran
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <form action="/bayar" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                
                
            </div>
            <div class="form-group row">
                <label for="nik_ayh" class="col-sm-4 col-form-label">Nama Siswa</label>
                <div class="col-sm-8">
                    <input type="text" name="nama_siswa" class="form-control" id="nama" value="<?php echo e(auth()->user()->name); ?>" readonly>
                </div>
            </div>
            <div class="form-group row">
                
                <label for="jurusan" class="col-sm-4 col-form-label">Jurusan</label>
                <div class="col-sm-8">
                <select type="text" name="jurusan" id="jurusan" class="form-control">
                <?php $__currentLoopData = $datajurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
                <option value="<?php echo e($item->nama_jurusan); ?>"><?php echo e($item->nama_jurusan); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            </div>
            <div class="form-group row">
                <label for="tlahir_ayh" class="col-sm-4 col-form-label">Total Biaya Siswa</label>
                <div class="col-sm-8">
                    <input type="text" name="biaya" class="form-control" value="Rp. 200.000" readonly>
                </div>
            </div>
            <div class="form-group row">
                <label for="tlahir_ayh" class="col-sm-4 col-form-label">Bukti Transaksi</label>
                <div class="col-sm-8">
                    <input type="file" name="bukti" id="image" required>
                </div>
            </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-info">Kirim</button>
                </div>
                </form>
            </div>
            </div>
        </div>
        </div>
</div>
    <!-- End of Main Content -->
    <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\ppdbskripsi\resources\views/user/form_pembayaran.blade.php ENDPATH**/ ?>