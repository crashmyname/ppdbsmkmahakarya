<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid">
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Data Orang Tua</h1>
        <p class="mb-4">Berikut adalah halaman Data Orang tua Siswa SMK Mahakarya Cikupa.</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Table orang Tua</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="table-datatables" width="100%" cellspacing="0">
                        <thead>
                            <tr align="center">
                                <th>No</th>
                                <th>Nama Ayah</th>
                                <th>Tempat Lahir</th>
                                <th>Tanggal Lahir</th>
                                <th>Pendidikan</th>
                                <th>Pekerjaan</th>
                                <th>Penghasilan</th>
                                <th>Nama Ibu</th>
                                <th>Tempat Lahir</th>
                                <th>Tanggal Lahir</th>
                                <th>Pendidikan</th>
                                <th>Pekerjaan</th>
                                <th>Penghasilan</th>
                                
                            </tr>
                        </thead>
                            <?php $__currentLoopData = $dataortu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr align="center">
                                <th><?php echo e(++$no); ?></th>
                                <th><?php echo e($item['nama_ayah']); ?></th>
                                <th><?php echo e($item['tempat_lahir_ayah']); ?></th>
                                <th><?php echo e($item['tgl_lahir_ayah']); ?></th>
                                <th><?php echo e($item['pendidikan_ayah']); ?></th>
                                <th><?php echo e($item['pekerjaan_ayah']); ?></th>
                                <th><?php echo e($item['penghasilan_ayah']); ?></th>
                                <th><?php echo e($item['nama_ibu']); ?></th>
                                <th><?php echo e($item['tempat_lahir_ibu']); ?></th>
                                <th><?php echo e($item['tgl_lahir_ibu']); ?></th>
                                <th><?php echo e($item['pendidikan_ibu']); ?></th>
                                <th><?php echo e($item['pekerjaan_ibu']); ?></th>
                                <th><?php echo e($item['penghasilan_ibu']); ?></th>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($dataortu->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\ppdbskripsi\resources\views/admin/dataortu.blade.php ENDPATH**/ ?>