<?php echo $__env->make('user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<div class="container-fluid">
    <?php if(session()->has('sukses')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo e(session('sukses')); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <?php $__currentLoopData = $datauser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
            <form action="/uprofil/<?php echo e($item->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <!-- Horizontal Form -->
            <!-- DATA SISWA -->
            <div class="card card-info">
                <div class="card-header">
                    <h3 class="card-title">DATA PROFIL</h3>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card-body">
                            <div class="form-group row">
                                <label for="Nisn" class="col-sm-4 col-form-label">Nama</label>
                                <div class="col-sm-8">
                                    <input type="text" name="name" class="form-control" id="Nisn" placeholder="Nama" value="<?php echo e($item->name); ?>" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Nisn" class="col-sm-4 col-form-label">Email</label>
                                <div class="col-sm-8">
                                    <input type="email" name="email" class="form-control" id="Nisn" placeholder="Email" value="<?php echo e($item->email); ?>" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Nama Lengkap" class="col-sm-4 col-form-label">Password</label>
                                <div class="col-sm-8">
                                    <input type="pass" name="password" class="form-control" id="nama" placeholder="Masukan Pass baru anda" required>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-info">Update Profil</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\ppdbskripsi\resources\views/user/form_profil.blade.php ENDPATH**/ ?>