@include('layout.navbar')
<!-- HOME -->
<br><br><br><br>
<section class="jumbotron text-center">
      <div class="container">
        <div class="row">
          <div class="col"><h1 class="display-4"><br> Selamat Datang</h1>
            <p class="lead">Di Web PPDB Online SMK Mahakarya Cikupa 
              <div class="list-group">
                 <a href="/register" class="list-group-item list-group-item-action active" aria-current="true">
                    Mulai Daftar Disini
                  </a></p></div>
              </div><br>
          <div class="col"><img src="./img/bg1.png" alt="smk" width="400" class="responsive"></div>
        </div>
      </div>
        {{-- <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="white" fill-opacity="1" d="M0,32L30,53.3C60,75,120,117,180,128C240,139,300,117,360,101.3C420,85,480,75,540,101.3C600,128,660,192,720,229.3C780,267,840,277,900,245.3C960,213,1020,139,1080,96C1140,53,1200,43,1260,58.7C1320,75,1380,117,1410,138.7L1440,160L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"></path>
        </svg> --}}
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#0099ff" fill-opacity="1" d="M0,32L34.3,26.7C68.6,21,137,11,206,53.3C274.3,96,343,192,411,202.7C480,213,549,139,617,117.3C685.7,96,754,128,823,170.7C891.4,213,960,267,1029,272C1097.1,277,1166,235,1234,197.3C1302.9,160,1371,128,1406,112L1440,96L1440,320L1405.7,320C1371.4,320,1303,320,1234,320C1165.7,320,1097,320,1029,320C960,320,891,320,823,320C754.3,320,686,320,617,320C548.6,320,480,320,411,320C342.9,320,274,320,206,320C137.1,320,69,320,34,320L0,320Z"></path></svg>
</section>
