<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa\DataSiswa;
use App\Models\Siswa\DataOrtu;
use App\Models\Siswa\DataPendidikan;

class DataController extends Controller
{
    public function insertform(request $request)
    {
        $validatedData = $request->validate([
            'nisn' => 'required|max:12|unique:data_siswas',
            'nama_lengkap' => 'required|min:5|max:50',
            'jenis_kelamin' => 'required|max:10',
            'tempat_lahir' => 'required|max:30',
            'tanggal_lahir' => 'required',
            'agama' => 'required|max:16',
            'alamat' => 'required|max:50',
            'rt' => 'required|max:4',
            'rw' => 'required|max:4',
            'kelurahan' => 'required|max:15',
            'kecamatan' => 'required|max:15',
            'kabupaten' => 'required|max:15',
            'provinsi' => 'required|max:15',
            'no_telp' => 'required|max:13',
            'email' => 'required|max:30|unique:data_siswas',
            'nama_ayah' => 'required|max:50',
            'tempat_lahir_ayah' => 'required|max:30',
            'tgl_lahir_ayah' => 'required',
            'pendidikan_ayah' => 'required|max:20',
            'pekerjaan_ayah' => 'required|max:20',
            'penghasilan_ayah' => 'required|max:30',
            'nama_ibu' => 'required|max:50',
            'tempat_lahir_ibu' => 'required|max:30',
            'tgl_lahir_ibu' => 'required',
            'pendidikan_ibu' => 'required|max:20',
            'pekerjaan_ibu' => 'required|max:20',
            'penghasilan_ibu' => 'required|max:30',
            'nama_wali' => '',
            'tempat_lahir_wali' => '',
            'tgl_lahir_wali' => '',
            'pendidikan_wali' => '',
            'pekerjaan_wali' => '',
            'penghasilan_wali' => '',
            'jns_pendaftaran' => 'required|max:10',
            'jalur_pendaftaran' => 'required|max:10',
            'nama_sekolah' => 'required|max:50',
            // 'stts_sekolah' => 'required|max:255',
            'alamat_sekolah' => 'required|max:50',
            'jurusan' => 'required|max:40',
        ]);
        // dd($validatedData);
        DataSiswa::create($validatedData);
        DataOrtu::create($validatedData);
        DataPendidikan::create($validatedData);
        $request->session()->flash('sukses', 'Data berhasil tersimpan');
        return redirect('/dashboard');
    }

    public function info()
    {
        return view('info');
    }
}
